package com.mycompany.zerohunger

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
