// Export pages
export '/welcome_page/welcome_page_widget.dart' show WelcomePageWidget;
export '/login_page/login_page_widget.dart' show LoginPageWidget;
export '/signup_page/signup_page_widget.dart' show SignupPageWidget;
export '/phone_s_ignin/phone_s_ignin_widget.dart' show PhoneSIgninWidget;
export '/verify_s_m_s_page/verify_s_m_s_page_widget.dart'
    show VerifySMSPageWidget;
export '/forget_password_page/forget_password_page_widget.dart'
    show ForgetPasswordPageWidget;
export '/home_page/home_page_widget.dart' show HomePageWidget;
export '/profile/profile_widget.dart' show ProfileWidget;
export '/details_page/details_page_widget.dart' show DetailsPageWidget;
export '/gallery/gallery_widget.dart' show GalleryWidget;
